# Copyright 2026 Tinfoil Hat Linux
# Distributed under the terms of the GNU General Public License v2

EAPI=8

DESCRIPTION="Text Editor V1 - Simple terminal text editor for THL"
HOMEPAGE="https://github.com/Andrew3000lol/Tinfoil-Hat-Linux-ReMake"
SRC_URI=""

LICENSE="GPL-2"
SLOT="0"
KEYWORDS="amd64"

RDEPEND=""
DEPEND=""

S="${WORKDIR}"

src_install() {
    exeinto /usr/bin
    newexe "${FILESDIR}/Text_EditorV1" text-editor-v1
}
