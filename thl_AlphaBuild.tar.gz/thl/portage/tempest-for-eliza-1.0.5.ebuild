# /usr/local/portage/media-sound/tempest-for-eliza/tempest-for-eliza-1.0.5.ebuild
# TinfoilHat Linux - local overlay ebuild for Tempest for Eliza
# Place in your local overlay, e.g. /usr/local/portage/
#
# Setup local overlay first:
#   mkdir -p /usr/local/portage/media-sound/tempest-for-eliza
#   cp this file there
#   Add to /etc/portage/repos.conf/local.conf:
#     [local]
#     location = /usr/local/portage
#     masters = gentoo
#     auto-sync = no
#   Then: ebuild tempest-for-eliza-1.0.5.ebuild manifest
#   Then: emerge tempest-for-eliza

EAPI=8

DESCRIPTION="Uses your monitor to transmit AM radio signals as music"
HOMEPAGE="http://www.erikyyy.de/tempest/"
SRC_URI="http://www.erikyyy.de/tempest/tempest_for_eliza-${PV}.tar.gz"

LICENSE="GPL-2"
SLOT="0"
KEYWORDS="amd64 x86"
IUSE="lcd"

DEPEND="
    media-libs/libsdl
    x11-libs/libX11
"
RDEPEND="${DEPEND}"

S="${WORKDIR}/tempest_for_eliza-${PV}"

src_configure() {
    econf \
        --with-x \
        $(use_with lcd)
}

src_compile() {
    emake
}

src_install() {
    emake DESTDIR="${D}" install
    dodoc README
    # Install song files
    insinto /usr/share/tempest-for-eliza/songs
    doins songs/*
}

pkg_postinst() {
    elog "Usage: tempest [frequency_MHz] [songfile]"
    elog "Example: tempest 100.0 /usr/share/tempest-for-eliza/songs/eliza"
    elog ""
    elog "Tune your AM radio to the frequency you chose."
    elog "Works best with a CRT monitor. For LCD, see tempest-lcd on GitHub."
    elog ""
    elog "NOTE: THL has kernel.random.trust_cpu=0 set — this program's EM"
    elog "emissions are intentional and expected on this system."
}
